console.log("Script general cargado correctamente ✅");

const VOTOS_MUNDIALES_KEY = "votosMundiales";

document.addEventListener("DOMContentLoaded", () => {
  const rl = document.getElementById("reading-line");
  rl?.classList.add("hidden");
});

// Seguridad y Utilidad
function safeEvent(element, event, callback) {
  if (element) element.addEventListener(event, callback);
}


// Roles y modales
// Rol actual
let rol = localStorage.getItem("rolActual") || "lector";

// Actualización de la interfaz según el rol
function actualizarVistaPorRol() {
  const botonAdmin = document.querySelector(".btn-admin");
  const botonesEditar = document.querySelectorAll(".btn-editar");

  if (botonAdmin) {
    botonAdmin.style.display = rol === "admin" ? "block" : "none";
  }

  botonesEditar.forEach((btn) => {
    btn.style.display = rol === "admin" ? "inline-block" : "none";
  });
}

// Ejecutar al cargar la página
document.addEventListener("DOMContentLoaded", actualizarVistaPorRol);

function cambiarRol(nuevoRol) {
  rol = nuevoRol;
  actualizarVistaPorRol();
  console.log("Rol actual:", rol);
}

actualizarVistaPorRol();

const modalAviso = document.getElementById("modal-aviso");
const modalCrear = document.getElementById("modal-crear");
const abrirCrear = document.getElementById("abrir-crear");
const cerrarModales = document.querySelectorAll(".cerrar-modal");
const likeButtons = document.querySelectorAll(".like-btn");

// Abrir modal de crear
safeEvent(abrirCrear, "click", () => modalCrear?.classList.add("activo"));

// Cerrar modales
cerrarModales.forEach((btn) =>
  safeEvent(btn, "click", () => {
    modalAviso?.classList.remove("activo");
    modalCrear?.classList.remove("activo");
  })
);

likeButtons.forEach((btn) =>
  safeEvent(btn, "click", (event) => {
    event.preventDefault();
    if (rol === "lector") {
      modalAviso?.classList.add("activo");
    } else {
      alert("Like registrado 👍 (simulación)");
    }
  })
);


//   Login y registro
document.addEventListener("DOMContentLoaded", () => {

  const btnRegistro = document.getElementById("btn-registrarse");
  const btnLogin = document.getElementById("btn-login");
  const btnLogout = document.getElementById("btn-logout");

  let usuarioActual = null;

  try {
    usuarioActual = JSON.parse(localStorage.getItem("usuarioActual"));
  } catch {
    usuarioActual = null;
  }


// Inexistenccia de usuario
if (!usuarioActual) {

    // Mostrar login y registro en las páginas
    btnRegistro?.classList.remove("oculto");
    btnLogin?.classList.remove("oculto");
    btnLogout?.classList.add("oculto");

    return;
}


  // Existencia del usuario
  btnRegistro?.classList.add("oculto");
  btnLogin?.classList.add("oculto");
  btnLogout?.classList.remove("oculto");

});



// Accesibilidad
const menu = document.getElementById("accessibility-menu");
const toggleButton = document.getElementById("accessibility-toggle");
const increaseTextBtn = document.getElementById("increase-text");
const decreaseTextBtn = document.getElementById("decrease-text");
const resetTextBtn = document.getElementById("reset-text");
const toggleDislexia = document.getElementById("toggle-dyslexic");
const toggleContrast = document.getElementById("toggle-contrast");
const toggleTheme = document.getElementById("toggle-theme");
const toggleReadingLine = document.getElementById("toggle-reading-line");
const readingLine = document.getElementById("reading-line");

let fontSize = 100;
let readingLineEnabled = false;

// Mostrar u ocultar menú
safeEvent(toggleButton, "click", () => {
  menu?.classList.toggle("hidden");
});

// Tamaño de texto
safeEvent(increaseTextBtn, "click", () => {
  fontSize += 10;
  document.body.style.fontSize = fontSize + "%";
});
safeEvent(decreaseTextBtn, "click", () => {
  fontSize = Math.max(50, fontSize - 10);
  document.body.style.fontSize = fontSize + "%";
});
safeEvent(resetTextBtn, "click", () => {
  fontSize = 100;
  document.body.style.fontSize = "100%";
});

// Fuente OpenDyslexic
safeEvent(toggleDislexia, "click", () => {
  document.body.classList.toggle("fuente-dislexica");
  if (document.body.classList.contains("fuente-dislexica")) {
    toggleDislexia.textContent = "Roboto (por defecto)";
  } else {
    toggleDislexia.textContent = "OpenDyslexic";
  }
});

// Contraste
safeEvent(toggleContrast, "click", () => {
  document.body.classList.toggle("high-contrast");
});

// Tema oscuro o claro
safeEvent(toggleTheme, "click", () => {
  document.body.classList.toggle("dark-mode");
});

// Línea de lectura
safeEvent(toggleReadingLine, "click", () => {
  readingLineEnabled = !readingLineEnabled;
  readingLine?.classList.toggle("hidden", !readingLineEnabled);
});
document.addEventListener("mousemove", (e) => {
  if (readingLineEnabled && readingLine) {
    readingLine.style.top = e.clientY - 15 + "px";
  }
});

// Página del Mundial
function inicializarMundiales() {
  console.log("Página de Mundiales lista ⚽");

  const gridMundiales = document.querySelector(".grid-mundiales");
  const ordenarSelect = document.querySelector(".ordenar");
  const barraBusqueda = document.querySelector(".busqueda");
  const tarjetas = Array.from(gridMundiales.querySelectorAll(".tarjeta"));

  // Tarjetas visibbles
  function mostrarMundiales(lista) {
    gridMundiales.innerHTML = "";
    lista.forEach((t) => gridMundiales.appendChild(t));
  }

  // Año
  function obtenerAnio(tarjeta) {
    const texto = tarjeta.querySelector("h3").textContent;
    const coincidencia = texto.match(/\b(19|20)\d{2}\b/);
    return coincidencia ? parseInt(coincidencia[0]) : 0;
  }

  // Filtrado en texto
  function filtrarMundiales(texto) {
    const filtradas = tarjetas.filter((t) =>
      t.querySelector("h3").textContent.toLowerCase().includes(texto.toLowerCase())
    );
    mostrarMundiales(filtradas);
  }

  // Ordenación
  function ordenarMundiales(opcion) {
    let ordenadas = [...tarjetas];

    if (opcion.includes("cronológico")) {
      ordenadas.sort((a, b) => obtenerAnio(a) - obtenerAnio(b));
    } else if (opcion.includes("País")) {
    ordenadas.sort((a, b) => {
      const tituloA = a.querySelector("h3").textContent.toLowerCase();
      const tituloB = b.querySelector("h3").textContent.toLowerCase();

      const paisA = tituloA.split("-")[1]?.trim() || tituloA;
      const paisB = tituloB.split("-")[1]?.trim() || tituloB;

      return paisA.localeCompare(paisB);
    });

    } else if (opcion.includes("likes") || opcion.includes("comentarios")) {

      ordenadas.sort(() => Math.random() - 0.5);
    }

    mostrarMundiales(ordenadas);
  }

  // BBsuqueda en tiempo real
  barraBusqueda.addEventListener("input", (e) => {
    filtrarMundiales(e.target.value);
  });

  // Ordenación en selección
  ordenarSelect.addEventListener("change", (e) => {
    ordenarMundiales(e.target.value);
  });

    // Publicación de mundial
  const botonPublicar = document.getElementById("publicar-mundial");
  const modalCrear = document.getElementById("modal-crear");

  if (botonPublicar) {
    botonPublicar.addEventListener("click", () => {
      if (rol !== "admin") {
        alert("Solo el administrador puede publicar mundiales ⚠️");
        return;
      }

      const titulo = document.getElementById("nuevo-titulo").value.trim();
      const descripcion = document.getElementById("nueva-descripcion").value.trim();
      const imagenInput = document.getElementById("nueva-imagen");

      if (!titulo || !descripcion || !imagenInput.files[0]) {
        alert("Por favor completa todos los campos antes de publicar.");
        return;
      }

      //URL temporal para mostrar la imagen seleccionada
      const imagenURL = URL.createObjectURL(imagenInput.files[0]);

      // Nueva tarjeta
      const nuevaTarjeta = document.createElement("a");
      nuevaTarjeta.href = "mundial2.html";
      nuevaTarjeta.classList.add("tarjeta");
      nuevaTarjeta.innerHTML = `
        <img src="${imagenURL}" alt="${titulo}">
        <h3>${titulo}</h3>

        <div class="likes-mundial">
          <button class="btn-like-mundial" data-id="${titulo}">
            👍 <span class="contador-like">0</span>
          </button>

          <button class="btn-dislike-mundial" data-id="${titulo}">
            👎 <span class="contador-dislike">0</span>
          </button>
        </div>
      `;


      // Contadores like y dislike
      const btnLike = nuevaTarjeta.querySelector(".btn-like-mundial");
      const btnDislike = nuevaTarjeta.querySelector(".btn-dislike-mundial");

      btnLike.addEventListener("click", () =>
        registrarVotoMundial(btnLike.dataset.id, "like", nuevaTarjeta)
      );

      btnDislike.addEventListener("click", () =>
        registrarVotoMundial(btnDislike.dataset.id, "dislike", nuevaTarjeta)
      );



      gridMundiales.appendChild(nuevaTarjeta);

      // Limpieza de campos
      modalCrear.classList.remove("activo");
      document.getElementById("nuevo-titulo").value = "";
      document.getElementById("nueva-descripcion").value = "";
      document.getElementById("nueva-imagen").value = "";

      alert(`Nuevo mundial "${titulo}" agregado exitosamente`);
    });
  }
}

function registrarVotoMundial(id, tipo, tarjeta) {
    const user = JSON.parse(localStorage.getItem("usuarioActual"));
    if (!user) {
        alert("Debe iniciar sesión para votar.");
        return;
    }

    const votos = JSON.parse(localStorage.getItem("votosMundiales")) || {};
    const usuarioId = user.email || user.correo || user.nombre;
    const llave = usuarioId + ":" + id;

    let votoPrevio = votos[llave];

    let likeSpan = tarjeta.querySelector(".contador-like");
    let dislikeSpan = tarjeta.querySelector(".contador-dislike");

    let likes = parseInt(likeSpan.textContent);
    let dislikes = parseInt(dislikeSpan.textContent);

    if (votoPrevio === tipo) {
        if (tipo === "like") likes--;
        else dislikes--;
        delete votos[llave];
    } else {
        if (votoPrevio === "like") likes--;
        if (votoPrevio === "dislike") dislikes--;

        if (tipo === "like") likes++;
        else dislikes++;

        votos[llave] = tipo;
    }

    likeSpan.textContent = likes;
    dislikeSpan.textContent = dislikes;

    localStorage.setItem("votosMundiales", JSON.stringify(votos));
}





// Detalles mundial
function inicializarDetalleMundial() {
  console.log("Página de detalle de Mundial lista 🏆");

  // SLikes

  const tarjeta = document.querySelector(".likes-mundial");
  const btnLike = document.querySelector(".btn-like-mundial");
  const btnDislike = document.querySelector(".btn-dislike-mundial");

  if (btnLike && btnDislike) {
    btnLike.addEventListener("click", () =>
      registrarVotoMundial(btnLike.dataset.id, "like", tarjeta)
    );

    btnDislike.addEventListener("click", () =>
      registrarVotoMundial(btnDislike.dataset.id, "dislike", tarjeta)
    );
  }

 
  // Editar botón
  const btnEditar = document.querySelector(".detalle .btn");
  safeEvent(btnEditar, "click", () => {
    if (rol !== "admin") {
      alert("Solo el administrador puede editar mundiales ⚠️");
    } else {
      alert("Función de edición en desarrollo ✏️");
    }
  });
}



// Inicio de la página
window.addEventListener("load", () => {
  if (document.body.classList.contains("pagina-mundiales")) inicializarMundiales();
  if (document.body.classList.contains("pagina-detalle")) inicializarDetalleMundial();
});

console.log("Script general cargado correctamente ✅");

// Función para eventos
function safeEvent(el, ev, fn) {
  if (el) el.addEventListener(ev, fn);
}

document.addEventListener("DOMContentLoaded", () => {


  // Habilitar login y registro
  const btnLogin = document.getElementById("btn-login");
  const btnRegistrarse = document.getElementById("btn-registrarse");
  const btnLogout = document.getElementById("btn-logout");

  safeEvent(btnLogin, "click", () => window.location.href = "login.html");
  safeEvent(btnRegistrarse, "click", () => window.location.href = "registro.html");


  // Mostraru ocultar botones según sesión
  const usuarioActual = JSON.parse(localStorage.getItem("usuarioActual"));

  if (!usuarioActual) {
    btnLogin?.classList.remove("oculto");
    btnRegistrarse?.classList.remove("oculto");
    btnLogout?.classList.add("oculto");
  } else {
    btnLogin?.classList.add("oculto");
    btnRegistrarse?.classList.add("oculto");
    btnLogout?.classList.remove("oculto");

  }

});

/* Funcionalidad Móvil: Menú & Perfil */
document.addEventListener("DOMContentLoaded", () => {

  const btnMenu = document.getElementById("btn-menu");
  const btnPerfil = document.getElementById("btn-header-perfil");
  const navMenu = document.querySelector(".menu");

  // Abrir/cerrar menú hamburguesa
  if (btnMenu) {
    btnMenu.addEventListener("click", () => {
      navMenu.classList.toggle("abierto");
    });
  }

  // Icono de perfil
  if (btnPerfil) {
    btnPerfil.addEventListener("click", () => {
      let usuario = JSON.parse(localStorage.getItem("usuarioActual"));

      if (usuario) {
        window.location.href = "perfil.html";
      } else {
        window.location.href = "login.html";
      }
    });
  }

});


//   Menú hamburguesa
document.addEventListener("DOMContentLoaded", () => {
  const btnMenu = document.getElementById("btn-menu");
  const btnHeaderPerfil = document.getElementById("btn-header-perfil");

  // Abrir / cerrar menú
  safeEvent(btnMenu, "click", () => {
    document.body.classList.toggle("menu-abierto");
  });

  // Ir a perfil al tocar el icono
  safeEvent(btnHeaderPerfil, "click", () => {
    window.location.href = "perfil.html";
  });
});

document.getElementById("btn-cambiar-foto").addEventListener("click", () => {
    document.getElementById("input-foto").click();
});

// Subir foto
document.getElementById("input-foto").addEventListener("change", function () {
    const archivo = this.files[0];
    if (!archivo) return;

    const lector = new FileReader();
    lector.onload = function (e) {
        document.getElementById("perfil-foto").src = e.target.result;

        // Guardar la imagen en localStorage para que no se pierda
        localStorage.setItem("fotoPerfil", e.target.result);
    };
    lector.readAsDataURL(archivo);
});

// Imagen cargandose
window.addEventListener("DOMContentLoaded", () => {
    const fotoGuardada = localStorage.getItem("fotoPerfil");
    if (fotoGuardada) {
        document.getElementById("perfil-foto").src = fotoGuardada;
    }
});

if (document.body.classList.contains("pagina-detalle"))
  inicializarDetalleMundial();
