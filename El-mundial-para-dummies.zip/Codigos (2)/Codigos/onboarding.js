document.addEventListener("DOMContentLoaded", () => {

    if (localStorage.getItem("onboardingCompletado") === "si") return;

    let pasos = [];

    // Página detectada
    const body = document.body;

    
    //  Onboarding en index
  
    if (body.classList.contains("pagina-index")) {
        pasos = [
            {
                titulo: "¡Bienvenido/a a El Mundial Para Dummies!",
                texto: "Aquí podrás aprender sobre los mundiales de una forma sencilla y divertida."
            },
            {
                titulo: "Acceso rápido",
                texto: "Usa el menú de arriba para navegar entre Mundiales, Publicaciones y tu Perfil."
            },
            {
                titulo: "Accesibilidad",
                texto: "Con el botón azul ♿ puedes ajustar tamaño de letra, contraste, tema oscuro y más."
            }
        ];
    }

   
    // Onboarding mundiales
    if (body.classList.contains("pagina-mundiales")) {
        pasos = [
            {
                titulo: "Explora todos los mundiales",
                texto: "Aquí verás una lista de todas las ediciones de la Copa del Mundo."
            },
            {
                titulo: "Buscar",
                texto: "En la barra de búsqueda puedes encontrar un mundial escribiendo su año, país o si es masculino / femenino."
            },
            {
                titulo: "Ordenar",
                texto: "Usa el selector de 'Ordenar por...' para ordenar los mundiales por año, país o popularidad."
            },
            {
                titulo: "Detalles",
                texto: "Haz clic en cualquier mundial para ver información más completa."
            }
        ];
    }

 
    // Onboarding en publicaciones
    if (body.classList.contains("pagina-publicaciones")) {
        pasos = [
            {
                titulo: "Bienvenido al área de publicaciones",
                texto: "Aquí puedes ver artículos y contenido creado por los usuarios."
            },
            {
                titulo: "Filtrar por categorías",
                texto: "Utiliza el selecto de categorias para filtrar las publicaciones que deseas ver."
            },
            {
                titulo: "Crear tu propia publicación",
                texto: "Si deseas publicar debes registrarte o iniciar sesión primero y esperar a que esta sea aprobada por el administrador."
            },
            {
                titulo: "Detalles",
                texto: "Haz clic en cualquier publicación para abrirla y ver su contenido completo."
            }
        ];
    }

    // Si no hay pasos definidos (otra página), no mostrar onboarding
    if (pasos.length === 0) return;


    // Onboarding

    const overlay = document.getElementById("onboarding-overlay");
    const titulo = document.getElementById("onboarding-title");
    const texto = document.getElementById("onboarding-text");

    const btnSiguiente = document.getElementById("onboarding-next");
    const btnSaltar = document.getElementById("onboarding-skip");

    overlay.classList.remove("onboarding-hidden");

    let pasoActual = 0;

    function mostrarPaso(i) {
        titulo.textContent = pasos[i].titulo;
        texto.textContent = pasos[i].texto;

        btnSiguiente.textContent = (i === pasos.length - 1) ? "Terminar" : "Siguiente";
    }

    mostrarPaso(pasoActual);

    // Botón siguiente
    btnSiguiente.addEventListener("click", () => {
        pasoActual++;

        if (pasoActual >= pasos.length) {
            overlay.classList.add("onboarding-hidden");
            localStorage.setItem("onboardingCompletado", "si");
            return;
        }

        mostrarPaso(pasoActual);
    });

    // Botón saltar
    btnSaltar.addEventListener("click", () => {
        overlay.classList.add("onboarding-hidden");
        localStorage.setItem("onboardingCompletado", "si");
    });

});
