
// publicaciones
(function () {
    const STORAGE_KEY = "publicaciones";
    const VOTOS_KEY   = "votosPublicaciones";

    // Listas fijas
    const CATEGORIAS = ["Jugadas","Entrevistas","Partidos","Estadísticas","Asistentes","Incidentes","Polémicas","Sedes","Cultura"];
    const MUNDIALES = [
      { anio: 2023, pais: "Australia" },
      { anio: 2022, pais: "Qatar" },
      { anio: 2015, pais: "Canada" },
      { anio: 2014, pais: "Brasil" },
      { anio: 2011, pais: "Alemania" },
      { anio: 2010, pais: "África" },
      { anio: 1995, pais: "Suecia" },
      { anio: 1991, pais: "China" },
      { anio: 1934, pais: "Italia" },
      { anio: 1930, pais: "Uruguay" }
    ];

    // ---- Utilidades ----
    function getRolActual() { return localStorage.getItem("rolActual") || "lector"; }
    function getUsuarioActual() { try { return JSON.parse(localStorage.getItem("usuarioActual")); } catch { return null; } }
    function nombreUsuarioActual() { const u = getUsuarioActual(); if(!u) return "Invitado"; return u.nombre || u.email || u.correo || "Usuario"; }
    function leerPublicaciones() { try { const data = JSON.parse(localStorage.getItem(STORAGE_KEY)); return Array.isArray(data) ? data : []; } catch { return []; } }
    function guardarPublicaciones(lista) { localStorage.setItem(STORAGE_KEY, JSON.stringify(lista)); }
    function leerVotos() { try { const data = JSON.parse(localStorage.getItem(VOTOS_KEY)); return data && typeof data === "object" ? data : {}; } catch { return {}; } }
    function guardarVotos(votos) { localStorage.setItem(VOTOS_KEY, JSON.stringify(votos)); }
    function generarId() { return "pub-" + Date.now() + "-" + Math.floor(Math.random() * 100000); }
    function obtenerQueryId() { const params = new URLSearchParams(window.location.search); return params.get("id"); }
    function mostrarModalAvisoLogin() { const modal = document.getElementById("modal-aviso"); if (modal) { modal.style.display = "flex"; } else { alert("Para realizar esta acción necesita iniciar sesión o registrarse."); } }
    function abrirModal(modal) { if (!modal) return; modal.style.display = "flex"; }
    function cerrarModal(modal) { if (!modal) return; modal.style.display = "none"; }

    function actualizarContadorPendientesEnUI() {
        const span = document.getElementById("contador-pendientes");
        if (!span) return;
        const publicaciones = leerPublicaciones();
        const pendientes = publicaciones.filter(p => p.estado === "pendiente").length;
        span.textContent = pendientes > 0 ? String(pendientes) : "0";
        span.style.display = pendientes > 0 ? "inline-block" : "none";
    }

 
    // Publicaciones
    function initPaginaLista() {
        if (!document.body.classList.contains("pagina-publicaciones")) return;

        const contenedor = document.querySelector(".grid-publicaciones");
        const inputBusqueda = document.getElementById("busqueda-publicaciones");
        const btnCategorias = document.getElementById("btn-ordenar-publicaciones"); 
        const categoriaSelect = document.getElementById("categoria-filter-select");

        if (categoriaSelect) {
            categoriaSelect.addEventListener("change", () => {
                filtrarYOrdenarPublicaciones();
            });
        }

        const btnHacerPublicacion = document.getElementById("btn-hacer-publicacion");
        const btnIrPendientes = document.getElementById("btn-publicaciones-pendientes");
        const rol = getRolActual();

        if (!contenedor) return;

        let ordenAsc = true;
        let filtroCategoria = ""; 


        function crearDropdownCategorias() {
            if (document.getElementById("categoria-filter-select")) return;
            const wrap = document.createElement("div");
            wrap.id = "categoria-filter-wrap";
            wrap.style.position = "absolute";
            wrap.style.zIndex = "1001";
            wrap.style.right = "20px";
            wrap.style.top = "70px";
            wrap.style.background = "#fff";
            wrap.style.border = "1px solid #ccc";
            wrap.style.padding = "8px";
            wrap.style.borderRadius = "8px";
            wrap.style.boxShadow = "0 3px 10px rgba(0,0,0,0.15)";

            const select = document.createElement("select");
            select.id = "categoria-filter-select";
            const opcTodas = document.createElement("option");
            opcTodas.value = "";
            opcTodas.textContent = "Todas las categorías";
            select.appendChild(opcTodas);
            CATEGORIAS.forEach(c => {
                const o = document.createElement("option");
                o.value = c;
                o.textContent = c;
                select.appendChild(o);
            });

            const btnCerrar = document.createElement("button");
            btnCerrar.textContent = "Cerrar";
            btnCerrar.className = "btn";
            btnCerrar.style.display = "block";
            btnCerrar.style.marginTop = "8px";

            wrap.appendChild(select);
            wrap.appendChild(btnCerrar);
            document.body.appendChild(wrap);

            select.addEventListener("change", () => {
                filtroCategoria = select.value;
                filtrarYOrdenarPublicaciones();
            });

            btnCerrar.addEventListener("click", () => {
                wrap.remove();
            });
        }

        function filtrarYOrdenarPublicaciones() {
            const todas = leerPublicaciones()
                .filter(p => p.estado === "aprobada");

            const texto = (inputBusqueda?.value || "").toLowerCase();
            const categoriaFiltro = (document.getElementById("categoria-filter-select")?.value || "").toLowerCase();

            let filtradas = todas.filter(p => {
                const cadena = (
                    (p.titulo || "") + " " +
                    (p.contenido || "") + " " +
                    (p.autor || "")
                ).toLowerCase();
                if (!cadena.includes(texto)) return false;

                if (categoriaFiltro) {
                    const catPub = (p.categoria || "").toLowerCase();
                    if (catPub !== categoriaFiltro) return false;
                }

                return true;
            });

            filtradas.sort((a, b) => {
                const fechaA = new Date(a.fechaElaboracion || a.id);
                const fechaB = new Date(b.fechaElaboracion || b.id);
                return ordenAsc ? fechaA - fechaB : fechaB - fechaA;
            });

            renderizarListado(filtradas);
        }


        function renderizarListado(lista) {
            contenedor.innerHTML = "";

            if (!lista.length) {
                const vacio = document.createElement("p");
                vacio.textContent = "No hay publicaciones todavía.";
                contenedor.appendChild(vacio);
                return;
            }

            lista.forEach(pub => {
                const tarjeta = document.createElement("a");
                tarjeta.className = "tarjeta-publicacion";
                tarjeta.href = "publicacion.html?id=" + encodeURIComponent(pub.id);

                let tituloMostrado = pub.titulo || "Sin título";
                const cat = pub.categoria || "";
                if (cat && !tituloMostrado.toLowerCase().includes(`(${cat.toLowerCase()})`)) {
                    tituloMostrado = `${tituloMostrado} (${cat})`;
                }

                tarjeta.innerHTML = `
                    <div class="tarjeta-imagen">
                        ${pub.imagen ? `<img src="${pub.imagen}" alt="${pub.titulo}">` : ""}
                    </div>
                    <div class="tarjeta-contenido">
                        <h3>${tituloMostrado}</h3>
                        <p class="tarjeta-autor">${pub.autor || ""}${pub.mundial ? " — " + pub.mundial.anio + " (" + pub.mundial.pais + ")" : ""}</p>
                    </div>
                `;

                contenedor.appendChild(tarjeta);
            });
        }

        // Eventos
        if (inputBusqueda) inputBusqueda.addEventListener("input", filtrarYOrdenarPublicaciones);

        if (btnCategorias) {
            btnCategorias.addEventListener("click", (e) => {
                //  dropdown
                crearDropdownCategorias();
            });
        }

        if (btnHacerPublicacion) {
            btnHacerPublicacion.addEventListener("click", () => {
                const usuario = getUsuarioActual();
                if (!usuario || getRolActual() === "lector") {
                    mostrarModalAvisoLogin();
                    return;
                }
                const modal = document.getElementById("modal-publicacion");
                abrirModal(modal);
            });
        }

        if (btnIrPendientes) {
            btnIrPendientes.addEventListener("click", () => { if (rol !== "admin") return; window.location.href = "publicaciones_pendientes.html"; });
        }

        filtrarYOrdenarPublicaciones();
        actualizarContadorPendientesEnUI();
        initModalCrearPublicacion();
    }


    // Hacerr publicación
    function initModalCrearPublicacion() {
        const modal = document.getElementById("modal-publicacion");
        if (!modal) return;

        const inputTitulo  = document.getElementById("titulo-publicacion-input");
        const inputResena  = document.getElementById("resena-publicacion-input");
        const selectCategoria = document.getElementById("categoria-publicacion-select");
        const selectMundial = document.getElementById("mundial-publicacion-select");
        const inputImagen  = document.getElementById("imagen-publicacion-input");
        const btnAbrirFile = document.getElementById("btn-agregar-imagen-publicacion");
        const btnPublicar  = document.getElementById("btn-publicar");
        const btnCerrar    = modal.querySelector(".btn-cerrar-modal");

        let imagenDataURL = null;

        if (btnAbrirFile && inputImagen) {
            btnAbrirFile.addEventListener("click", () => inputImagen.click());
        }

        if (inputImagen) {
            const estado = document.getElementById("estado-carga-imagen");

            inputImagen.addEventListener("change", e => {
                const file = e.target.files[0];
                if (!file) { imagenDataURL = null; return; }

                estado.style.display = "inline";  // mostrar "Cargando..."

                const reader = new FileReader();
                reader.onload = () => {
                    imagenDataURL = reader.result;
                    estado.textContent = "Imagen lista ✓";
                    setTimeout(() => estado.style.display = "none", 1000);
                };

                reader.readAsDataURL(file);
            });
        }


        if (btnCerrar) btnCerrar.addEventListener("click", () => cerrarModal(modal));

        if (btnPublicar) {
            btnPublicar.addEventListener("click", () => {
                const usuario = getUsuarioActual();
                const rol = getRolActual();
                if (!usuario || rol === "lector") { cerrarModal(modal); mostrarModalAvisoLogin(); return; }

                const tituloRaw = (inputTitulo?.value || "").trim();
                const resena = (inputResena?.value || "").trim();
                const categoria = (selectCategoria?.value || "").trim();
                const mundialVal = (selectMundial?.value || "").trim();

                if (!tituloRaw || !resena) { alert("Por favor, agrega un título y una reseña."); return; }

                let titulo = tituloRaw;
                if (categoria && !titulo.toLowerCase().includes(`(${categoria.toLowerCase()})`)) {
                    titulo = `${titulo} (${categoria})`;
                }

                let mundialObj = null;
                if (mundialVal) {
                    const parts = mundialVal.split("|");
                    if (parts.length === 2) {
                        mundialObj = { anio: parseInt(parts[0], 10), pais: parts[1] };
                    }
                }

                const ahora = new Date();
                const nueva = {
                    id: generarId(),
                    titulo,
                    contenido: resena,
                    resumen: resena.slice(0, 200),
                    categoria: categoria,
                    autor: nombreUsuarioActual(),
                    fechaElaboracion: ahora.toISOString(),
                    fechaAprobacion: rol === "admin" ? ahora.toISOString() : null,
                    estado: rol === "admin" ? "aprobada" : "pendiente",
                    imagen: imagenDataURL,
                    mundial: undefined, 
                    mundial: mundialObj,
                    likes: 0,
                    dislikes: 0,
                    comentarios: []
                };

                const publicaciones = leerPublicaciones();
                publicaciones.push(nueva);
                guardarPublicaciones(publicaciones);

                actualizarContadorPendientesEnUI();

                if (rol === "admin") alert("Publicación creada y aprobada.");
                else alert("Tu publicación quedó pendiente de aprobación por un administrador.");

                if (inputTitulo) inputTitulo.value = "";
                if (inputResena) inputResena.value = "";
                if (selectCategoria) selectCategoria.selectedIndex = 0;
                if (selectMundial) selectMundial.selectedIndex = 0;
                if (inputImagen) inputImagen.value = "";
                imagenDataURL = null;

                cerrarModal(modal);

                if (document.body.classList.contains("pagina-publicaciones") && rol === "admin") {
                    window.location.reload();
                }
            });
        }
    }

    // Detalles en publicación
    function initPaginaDetalle() {
        if (!document.body.classList.contains("pagina-detalle-publicacion")) return;
        const id = obtenerQueryId();
        if (!id) return;
        const publicaciones = leerPublicaciones();
        const pub = publicaciones.find(p => p.id === id);
        if (!pub) { alert("No se encontró la publicación."); return; }
        const rol = getRolActual();
        const usuario = getUsuarioActual();
        const nombre = nombreUsuarioActual();

        // elementos
        const img       = document.getElementById("publicacion-imagen");
        const tituloEl  = document.getElementById("publicacion-titulo");
        const resumenEl = document.getElementById("publicacion-resumen");
        const catEl     = document.getElementById("publicacion-categoria");
        const autorEl   = document.getElementById("publicacion-autor");
        const fechaElab = document.getElementById("publicacion-fecha-elaboracion");
        const fechaAprob= document.getElementById("publicacion-fecha-aprobacion");

        const btnLike   = document.getElementById("btn-like-publicacion");
        const btnDislike= document.getElementById("btn-dislike-publicacion");
        const spanLikes = document.getElementById("contador-likes");
        const spanDis   = document.getElementById("contador-dislikes");

        const campoComentario = document.getElementById("campo-comentario");
        const btnAñadirComentario = document.getElementById("btn-anadir-comentario");
        const contComentarios = document.getElementById("lista-comentarios");

        const btnHacerPublicacion = document.getElementById("btn-hacer-publicacion");
        const btnPendientes = document.getElementById("btn-publicaciones-pendientes");

        // rellenar
        if (img && pub.imagen) img.src = pub.imagen;
        if (tituloEl)  tituloEl.textContent = pub.titulo || "";
        if (resumenEl) resumenEl.textContent = pub.contenido || pub.resumen || "";
        if (catEl)     catEl.textContent = pub.categoria || "";
        if (autorEl)   autorEl.textContent = pub.autor || "";
        if (fechaElab) fechaElab.textContent = pub.fechaElaboracion ? new Date(pub.fechaElaboracion).toLocaleDateString() : "";
        if (fechaAprob) fechaAprob.textContent = pub.fechaAprobacion ? new Date(pub.fechaAprobacion).toLocaleDateString() : "-";

        // mostrar info de mundial 
        if (pub.mundial && tituloEl) {
            const spanMundial = document.createElement("p");
            spanMundial.textContent = `Mundial: ${pub.mundial.anio} — ${pub.mundial.pais}`;
            tituloEl.insertAdjacentElement("afterend", spanMundial);
        }

        if (spanLikes) spanLikes.textContent = String(pub.likes || 0);
        if (spanDis)   spanDis.textContent = String(pub.dislikes || 0);

        function renderComentarios() {
            if (!contComentarios) return;
            contComentarios.innerHTML = "";
            if (!pub.comentarios || !pub.comentarios.length) {
                const p = document.createElement("p");
                p.textContent = "No hay comentarios todavía.";
                contComentarios.appendChild(p);
                return;
            }
            pub.comentarios.forEach(com => {
                const fila = document.createElement("div");
                fila.className = "comentario-fila";
                fila.innerHTML = `
                    <div class="comentario-avatar"></div>
                    <div class="comentario-texto">
                        <strong>${com.autor || "Anónimo"}</strong>
                        <p>${com.texto}</p>
                    </div>
                `;
                if (rol === "admin" || (usuario && (com.autor === nombre))) {
                    const btnBorrar = document.createElement("button");
                    btnBorrar.className = "btn-borrar-comentario";
                    btnBorrar.innerHTML = "🗑";
                    btnBorrar.title = "Eliminar comentario";
                    btnBorrar.addEventListener("click", () => confirmarBorradoComentario(com.id));
                    fila.appendChild(btnBorrar);
                }
                contComentarios.appendChild(fila);
            });
        }

        function confirmarBorradoComentario(idComentario) {
            const modal = document.getElementById("modal-confirmar-borrado");
            const btnAceptar = modal?.querySelector("#btn-confirmar-borrado");
            const btnCancelar = modal?.querySelector("#btn-cancelar-borrado");
            if (!modal || !btnAceptar || !btnCancelar) {
                borrarComentario(idComentario);
                return;
            }
            abrirModal(modal);
            const handlerAceptar = () => { borrarComentario(idComentario); cerrarModal(modal); btnAceptar.removeEventListener("click", handlerAceptar); btnCancelar.removeEventListener("click", handlerCancelar); };
            const handlerCancelar = () => { cerrarModal(modal); btnAceptar.removeEventListener("click", handlerAceptar); btnCancelar.removeEventListener("click", handlerCancelar); };
            btnAceptar.addEventListener("click", handlerAceptar);
            btnCancelar.addEventListener("click", handlerCancelar);
        }

        function borrarComentario(idComentario) {
            pub.comentarios = (pub.comentarios || []).filter(c => c.id !== idComentario);
            guardarPublicaciones(actualizarPublicacion(pub));
            renderComentarios();
        }

        if (btnAñadirComentario && campoComentario) {
            btnAñadirComentario.addEventListener("click", () => {
                const user = getUsuarioActual();
                if (!user || getRolActual() === "lector") { mostrarModalAvisoLogin(); return; }
                const texto = campoComentario.value.trim();
                if (!texto) { alert("Escribe un comentario antes de añadirlo."); return; }
                const nuevoComentario = { id: generarId(), autor: nombreUsuarioActual(), texto, fecha: new Date().toISOString() };
                pub.comentarios = pub.comentarios || [];
                pub.comentarios.push(nuevoComentario);
                guardarPublicaciones(actualizarPublicacion(pub));
                campoComentario.value = "";
                renderComentarios();
            });
        }

        // votos 
        function actualizarPublicacion(pubActualizada) {
            const lista = leerPublicaciones();
            const index = lista.findIndex(p => p.id === pubActualizada.id);
            if (index !== -1) { lista[index] = pubActualizada; guardarPublicaciones(lista); }
            return lista;
        }

        function registrarVoto(tipo) {
            const usuario = getUsuarioActual();
            if (!usuario || getRolActual() === "lector") { mostrarModalAvisoLogin(); return; }
            const votos = leerVotos();
            const claveUsuario = (usuario.email || usuario.correo || usuario.nombre || "anon") + "";
            const llave = claveUsuario + ":" + pub.id;
            const votoAnterior = votos[llave];
            if (votoAnterior === tipo) {
                if (tipo === "like") pub.likes = Math.max(0, (pub.likes || 0) - 1);
                if (tipo === "dislike") pub.dislikes = Math.max(0, (pub.dislikes || 0) - 1);
                delete votos[llave];
            } else {
                if (votoAnterior === "like") pub.likes = Math.max(0, (pub.likes || 0) - 1);
                if (votoAnterior === "dislike") pub.dislikes = Math.max(0, (pub.dislikes || 0) - 1);
                if (tipo === "like") pub.likes = (pub.likes || 0) + 1;
                if (tipo === "dislike") pub.dislikes = (pub.dislikes || 0) + 1;
                votos[llave] = tipo;
            }
            guardarVotos(votos);
            guardarPublicaciones(actualizarPublicacion(pub));
            if (spanLikes) spanLikes.textContent = String(pub.likes || 0);
            if (spanDis)   spanDis.textContent = String(pub.dislikes || 0);
        }

        if (btnLike) btnLike.addEventListener("click", () => registrarVoto("like"));
        if (btnDislike) btnDislike.addEventListener("click", () => registrarVoto("dislike"));

        if (btnHacerPublicacion) btnHacerPublicacion.addEventListener("click", () => {
            const usuario = getUsuarioActual();
            if (!usuario || getRolActual() === "lector") { mostrarModalAvisoLogin(); return; }
            const modal = document.getElementById("modal-publicacion"); abrirModal(modal);
        });

        if (btnPendientes && rol === "admin") btnPendientes.addEventListener("click", () => window.location.href = "publicaciones_pendientes.html");

        renderComentarios();
        actualizarContadorPendientesEnUI();
        initModalCrearPublicacion();
    }


    // Pendientes
    function initPaginaPendientes() {
        if (!document.body.classList.contains("pagina-pendientes-publicaciones")) return;
        const rol = getRolActual();
        if (rol !== "admin") { alert("Solo un administrador puede revisar publicaciones pendientes."); window.location.href = "publicaciones.html"; return; }

        const img       = document.getElementById("publicacion-imagen");
        const tituloEl  = document.getElementById("publicacion-titulo");
        const resumenEl = document.getElementById("publicacion-resumen");
        const catEl     = document.getElementById("publicacion-categoria");
        const autorEl   = document.getElementById("publicacion-autor");
        const fechaElab = document.getElementById("publicacion-fecha-elaboracion");
        const btnAprobar = document.getElementById("btn-aprobar-publicacion");
        const btnRechazar= document.getElementById("btn-rechazar-publicacion");
        const btnVolver  = document.getElementById("btn-volver-publicaciones");

        let pendientes = leerPublicaciones().filter(p => p.estado === "pendiente");
        let indiceActual = 0;

        function mostrarActual() {
            pendientes = leerPublicaciones().filter(p => p.estado === "pendiente");
            const mensajeNoPendientes = document.getElementById("mensaje-no-pendientes");

            // Sin publicaciones
            if (!pendientes.length) {
                mensajeNoPendientes.classList.remove("oculto");

                img.classList.add("oculto");
                tituloEl.classList.add("oculto");
                resumenEl.textContent = "";
                catEl.textContent = "";
                autorEl.textContent = "";
                fechaElab.textContent = "";

                actualizarContadorPendientesEnUI();
                return;
            }

            // Si hay publis
            mensajeNoPendientes.classList.add("oculto");

            const pub = pendientes[indiceActual];

            img.src = pub.imagen || "";
            img.classList.remove("oculto");

            tituloEl.textContent = pub.titulo || "";
            tituloEl.classList.remove("oculto");

            resumenEl.textContent = pub.contenido || pub.resumen || "";

            catEl.textContent = pub.categoria || "";
            autorEl.textContent = pub.autor || "";
            fechaElab.textContent = pub.fechaElaboracion
                ? new Date(pub.fechaElaboracion).toLocaleDateString()
                : "";

            actualizarContadorPendientesEnUI();
        }



        function cambiarEstadoActual(nuevoEstado) {
            if (!pendientes.length) return;
            const lista = leerPublicaciones();
            const pubPendiente = pendientes[indiceActual];
            const idx = lista.findIndex(p => p.id === pubPendiente.id);
            if (idx === -1) return;
            if (nuevoEstado === "aprobada") { lista[idx].estado = "aprobada"; lista[idx].fechaAprobacion = new Date().toISOString(); }
            else if (nuevoEstado === "rechazada") { lista[idx].estado = "rechazada"; }
            guardarPublicaciones(lista);
            pendientes = lista.filter(p => p.estado === "pendiente");
            if (indiceActual >= pendientes.length) indiceActual = 0;
            mostrarActual();
        }

        if (btnAprobar) btnAprobar.addEventListener("click", () => cambiarEstadoActual("aprobada"));
        if (btnRechazar) btnRechazar.addEventListener("click", () => cambiarEstadoActual("rechazada"));
        if (btnVolver) btnVolver.addEventListener("click", () => { window.location.href = "publicaciones.html"; });

        mostrarActual();
    }


    // Inicialización
    document.addEventListener("DOMContentLoaded", () => {
        initPaginaLista();
        initPaginaDetalle();
        initPaginaPendientes();
    });
})();
