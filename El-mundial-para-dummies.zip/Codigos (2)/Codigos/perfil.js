document.addEventListener("DOMContentLoaded", () => {


    // Verificación del usuario
    const usuarioGuardado = JSON.parse(localStorage.getItem("usuarioActual"));
    const modalAviso = document.getElementById("modal-aviso");

    if (!usuarioGuardado) {

        modalAviso.classList.remove("oculto");
        modalAviso.style.display = "flex";

        document.getElementById("modal-login").onclick = () => location.href = "login.html";
        document.getElementById("modal-cancelar").onclick = () => location.href = "index.html";
        document.querySelector(".btn-cerrar-modal").onclick = () => location.href = "index.html";

        return;
    }


    // Datos del usuario
    const usuario = usuarioGuardado;

    document.getElementById("dato-usuario").textContent = usuario.nombre || usuario.email;
    document.getElementById("dato-nombre").textContent = usuario.nombre || "-";
    document.getElementById("dato-fecha").textContent = usuario.fechaNacimiento || "-";
    document.getElementById("dato-genero").textContent = usuario.genero || "-";
    document.getElementById("dato-pais").textContent = usuario.pais || "-";
    document.getElementById("dato-nacionalidad").textContent = usuario.nacionalidad || "-";
    document.getElementById("dato-correo").textContent = usuario.correo || usuario.email || "-";


    // Paneles
    const botones = document.querySelectorAll(".perfil-btn");
    const paneles = document.querySelectorAll(".perfil-panel");

    botones.forEach(btn => {
        btn.addEventListener("click", () => {

            botones.forEach(b => b.classList.remove("activo"));
            paneles.forEach(p => p.classList.remove("activo"));

            btn.classList.add("activo");
            document.getElementById(btn.dataset.panel).classList.add("activo");

            if (btn.dataset.panel === "panel-dashboard") {
                cargarDashboard();
            }
        });
    });


    cargarPublicacionesPerfil();



    // Preferencias
    const toggleFromPref = (prefID, accID) => {
        const prefBtn = document.getElementById(prefID);
        const accBtn = document.getElementById(accID);

        if (prefBtn && accBtn) {
            prefBtn.addEventListener("click", () => accBtn.click());
        }
    };

    // Tema
    document.getElementById("pref-tema")?.addEventListener("change", () => {
        document.getElementById("toggle-theme").click();
    });

    // Tamaño
    const increaseTextBtn = document.getElementById("pref-aumentar");
    const decreaseTextBtn = document.getElementById("pref-disminuir");
    const resetTextBtn = document.getElementById("pref-reset-letra");

    safeEvent(increaseTextBtn, "click", () => {
    fontSize += 10;
    document.body.style.fontSize = fontSize + "%";
    });
    safeEvent(decreaseTextBtn, "click", () => {
    fontSize = Math.max(50, fontSize - 10);
    document.body.style.fontSize = fontSize + "%";
    });
    safeEvent(resetTextBtn, "click", () => {
    fontSize = 100;
    document.body.style.fontSize = "100%";
    });

    // Dislexia
    toggleFromPref("pref-dislexia-toggle", "toggle-dyslexic");

    // Contraste
    document.getElementById("pref-contraste-si")?.addEventListener("click", () => {
        if (!document.body.classList.contains("high-contrast"))
            document.getElementById("toggle-contrast").click();
    });

    document.getElementById("pref-contraste-no")?.addEventListener("click", () => {
        if (document.body.classList.contains("high-contrast"))
            document.getElementById("toggle-contrast").click();
    });

    // Línea de lectura
    toggleFromPref("pref-linea-toggle", "toggle-reading-line");


});


// Edición de datos

document.addEventListener("DOMContentLoaded", () => {

    const usuarioActual = JSON.parse(localStorage.getItem("usuarioActual"));
    if (!usuarioActual) return;

    const usuarios = JSON.parse(localStorage.getItem("usuariosRegistrados")) || [];

    const btnEditar = document.getElementById("btn-editar-datos");
    const modalEditar = document.getElementById("modal-editar");
    const cerrarEditar = document.getElementById("cerrar-editar");

    const formEditar = document.getElementById("form-editar");

    const inputNombre = document.getElementById("edit-nombre");
    const inputFecha = document.getElementById("edit-fecha");
    const inputGenero = document.getElementById("edit-genero");
    const inputPais = document.getElementById("edit-pais");
    const inputNacionalidad = document.getElementById("edit-nacionalidad");
    const inputCorreo = document.getElementById("edit-correo");

    // modal con datos actuales
    btnEditar.addEventListener("click", () => {
        inputNombre.value = usuarioActual.nombre;
        inputFecha.value = usuarioActual.fechaNacimiento;
        inputGenero.value = usuarioActual.genero || "Hombre";
        inputPais.value = usuarioActual.pais;
        inputNacionalidad.value = usuarioActual.nacionalidad;
        inputCorreo.value = usuarioActual.correo;

        modalEditar.classList.remove("oculto");
    });

    // Cerrar
    cerrarEditar.addEventListener("click", () => {
        modalEditar.classList.add("oculto");
    });

    // Guardar cambios
    formEditar.addEventListener("submit", (e) => {
        e.preventDefault();

        usuarioActual.nombre = inputNombre.value;
        usuarioActual.fechaNacimiento = inputFecha.value;
        usuarioActual.genero = inputGenero.value;
        usuarioActual.pais = inputPais.value;
        usuarioActual.nacionalidad = inputNacionalidad.value;
        usuarioActual.correo = inputCorreo.value;

        // Guardar en localStorage
        localStorage.setItem("usuarioActual", JSON.stringify(usuarioActual));

        const index = usuarios.findIndex(u => u.correo === usuarioActual.correo);
        if (index !== -1) usuarios[index] = usuarioActual;

        localStorage.setItem("usuariosRegistrados", JSON.stringify(usuarios));

        document.getElementById("dato-nombre").textContent = usuarioActual.nombre;
        document.getElementById("dato-fecha").textContent = usuarioActual.fechaNacimiento;
        document.getElementById("dato-genero").textContent = usuarioActual.genero;
        document.getElementById("dato-pais").textContent = usuarioActual.pais;
        document.getElementById("dato-nacionalidad").textContent = usuarioActual.nacionalidad;
        document.getElementById("dato-correo").textContent = usuarioActual.correo;

        alert("Datos actualizados con éxito.");
        modalEditar.classList.add("oculto");
    });

});

function cargarDashboard() {
    const usuario = JSON.parse(localStorage.getItem("usuarioActual"));
    const publicaciones = JSON.parse(localStorage.getItem("publicaciones")) || [];

    // Publicaciones del usuario
    const mias = publicaciones.filter(p => p.autor === usuario.nombre);

    document.getElementById("dash-mis-publicaciones").textContent = mias.length;

    // Likes y dislikes
    const likes = usuario.likesDados || 0;
    const dislikes = usuario.dislikesDados || 0;

    document.getElementById("dash-likes").textContent = likes;
    document.getElementById("dash-dislikes").textContent = dislikes;

    // Tema
    document.getElementById("dash-tema").textContent =
        document.body.classList.contains("dark-mode") ? "Oscuro" : "Claro";
        

    // Preferencias activas
    let prefs = [];

    if (document.body.classList.contains("high-contrast")) prefs.push("Alto contraste");
    if (document.body.classList.contains("fuente-dislexica")) prefs.push("OpenDyslexic");
    if (document.body.classList.contains("dark-mode")) prefs.push("Modo oscuro");

    document.getElementById("dash-preferencias").textContent =
        prefs.length > 0 ? prefs.join(", ") : "Ninguna";
}



// Publicaciones en perfil

function cargarPublicacionesPerfil() {
    const contenedor = document.getElementById("perfil-publicaciones-lista");
    contenedor.innerHTML = "";

    const usuarioActual = JSON.parse(localStorage.getItem("usuarioActual"));
    if (!usuarioActual) return;

    const publicaciones = JSON.parse(localStorage.getItem("publicaciones")) || [];

    const miasAprobadas = publicaciones.filter(
        p => p.autor === usuarioActual.nombre && p.estado === "aprobada"
    );

    if (miasAprobadas.length === 0) {
        contenedor.innerHTML = "<p>No tienes publicaciones aprobadas aún.</p>";
        return;
    }

    miasAprobadas.forEach(pub => {
        const div = document.createElement("div");
        div.className = "perfil-pub-card";

        div.innerHTML = `
            <img src="${pub.imagen || 'img/no-image.jpg'}" alt="">
            <h3>${pub.titulo}</h3>
        `;

        div.onclick = () =>
            location.href = "publicacion.html?id=" + pub.id;

        contenedor.appendChild(div);
    });
}
