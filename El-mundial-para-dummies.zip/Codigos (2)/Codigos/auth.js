// ==================================================
//  SISTEMA DE USUARIOS Y AUTENTICACIÓN
// ==================================================

// 🔹 Guardar usuarios en un arreglo en localStorage
function obtenerUsuarios() {
    return JSON.parse(localStorage.getItem("usuariosRegistrados")) || [];
}

function guardarUsuarios(lista) {
    localStorage.setItem("usuariosRegistrados", JSON.stringify(lista));
}

// ==================================================
//  REGISTRO
// ==================================================
document.addEventListener("DOMContentLoaded", () => {
    const formRegistro = document.getElementById("register-form");
    if (!formRegistro) return; // No ejecutar en otras páginas

    formRegistro.addEventListener("submit", (e) => {
        e.preventDefault();

        const nombre = document.getElementById("nombre").value.trim();
        const fecha = document.getElementById("fecha").value;
        const genero = document.getElementById("genero").value;
        const pais = document.getElementById("pais").value.trim();
        const nacionalidad = document.getElementById("nacionalidad").value.trim();
        const correo = document.getElementById("correo").value.trim();
        const password = document.getElementById("password").value;

        // --- Validar edad mínima ---
        const edad = calcularEdad(fecha);
        if (edad < 12) {
            alert("Debes tener al menos 12 años para registrarte.");
            return;
        }

        // --- Validar correo repetido ---
        const usuarios = obtenerUsuarios();
        if (usuarios.some(u => u.correo === correo)) {
            alert("Este correo ya está registrado");
            return;
        }

        // --- Crear usuario ---
        const nuevoUsuario = {
            usuario: nombre.toLowerCase().replace(/\s+/g, ""), // genera @usuario automático
            nombre,
            fechaNacimiento: fecha,
            genero, 
            pais,
            nacionalidad,
            correo,
            password,
            rol: "usuario"
        };

        usuarios.push(nuevoUsuario);
        guardarUsuarios(usuarios);

        alert("Registro exitoso. Ahora inicia sesión.");
        window.location.href = "login.html";
    });
});

// Calcular edad
function calcularEdad(fechaNacimiento) {
    const hoy = new Date();
    const cumple = new Date(fechaNacimiento);
    let edad = hoy.getFullYear() - cumple.getFullYear();
    const m = hoy.getMonth() - cumple.getMonth();
    if (m < 0 || (m === 0 && hoy.getDate() < cumple.getDate())) edad--;
    return edad;
}

// ==================================================
//  LOGIN
// ==================================================
document.addEventListener("DOMContentLoaded", () => {
    const formLogin = document.getElementById("login-form");
    if (!formLogin) return; // NO ejecutar si no estoy en login.html

    formLogin.addEventListener("submit", (e) => {
        e.preventDefault();

        const correo = document.getElementById("login-email").value.trim();
        const password = document.getElementById("login-password").value;
        const rolSeleccionado = document.getElementById("login-role").value;

        const usuarios = obtenerUsuarios();

        // Buscar el usuario por correo o nombre de usuario
        const usuario = usuarios.find(u =>
            (u.correo === correo || u.usuario === correo) && u.password === password
        );

        if (!usuario) {
            alert("Credenciales incorrectas");
            return;
        }

        // Guardar sesión
        localStorage.setItem("usuarioActual", JSON.stringify(usuario));
        localStorage.setItem("rolActual", rolSeleccionado);

        alert(`Bienvenido, ${usuario.nombre}`);
        window.location.href = "index.html";
    });
});

// ==================================================
//  SISTEMA GLOBAL DE SESIÓN (LOGOUT)
// ==================================================
document.addEventListener("DOMContentLoaded", () => {
    const btnRegistro = document.getElementById("btn-registrarse");
    const btnLogin = document.getElementById("btn-login");
    const btnLogout = document.getElementById("btn-logout");

    const usuarioActual = JSON.parse(localStorage.getItem("usuarioActual"));

    if (usuarioActual) {
        btnRegistro?.classList.add("oculto");
        btnLogin?.classList.add("oculto");
        btnLogout?.classList.remove("oculto");
    }

    btnLogout?.addEventListener("click", () => {
        localStorage.removeItem("usuarioActual");
        localStorage.setItem("rolActual", "lector");
        alert("Sesión cerrada correctamente.");
        window.location.href = "index.html";
    });

    btnRegistro?.addEventListener("click", () => {
        window.location.href = "registro.html";
    });

    btnLogin?.addEventListener("click", () => {
        window.location.href = "login.html";
    });
});
